# Silent — day tracking is shown via bossbar only, no chat spam
