# === UPDATE BOSSBAR ===
# Called every second during phase 8
# Bossbar counts down from 100 to 0 over 24000 ticks (1 day = 24000 ticks = 1200 seconds)
# Each second it loses ~0.083 value — we just use tick/240 as a percentage

# We can't do division easily in vanilla, so we do it with score thresholds
execute if score #tick ext_tick matches 0..240 run bossbar set extinction:timer value 100
execute if score #tick ext_tick matches 241..480 run bossbar set extinction:timer value 98
execute if score #tick ext_tick matches 481..720 run bossbar set extinction:timer value 96
execute if score #tick ext_tick matches 721..960 run bossbar set extinction:timer value 94
execute if score #tick ext_tick matches 961..1200 run bossbar set extinction:timer value 92
execute if score #tick ext_tick matches 1201..1440 run bossbar set extinction:timer value 90
execute if score #tick ext_tick matches 1441..1680 run bossbar set extinction:timer value 88
execute if score #tick ext_tick matches 1681..1920 run bossbar set extinction:timer value 86
execute if score #tick ext_tick matches 1921..2160 run bossbar set extinction:timer value 84
execute if score #tick ext_tick matches 2161..2400 run bossbar set extinction:timer value 82
execute if score #tick ext_tick matches 2401..2640 run bossbar set extinction:timer value 80
execute if score #tick ext_tick matches 2641..2880 run bossbar set extinction:timer value 78
execute if score #tick ext_tick matches 2881..3120 run bossbar set extinction:timer value 76
execute if score #tick ext_tick matches 3121..3360 run bossbar set extinction:timer value 74
execute if score #tick ext_tick matches 3361..3600 run bossbar set extinction:timer value 72
execute if score #tick ext_tick matches 3601..3840 run bossbar set extinction:timer value 70
execute if score #tick ext_tick matches 3841..4080 run bossbar set extinction:timer value 68
execute if score #tick ext_tick matches 4081..4320 run bossbar set extinction:timer value 66
execute if score #tick ext_tick matches 4321..4560 run bossbar set extinction:timer value 64
execute if score #tick ext_tick matches 4561..4800 run bossbar set extinction:timer value 62
execute if score #tick ext_tick matches 4801..5040 run bossbar set extinction:timer value 60
execute if score #tick ext_tick matches 5041..5280 run bossbar set extinction:timer value 58
execute if score #tick ext_tick matches 5281..5520 run bossbar set extinction:timer value 56
execute if score #tick ext_tick matches 5521..5760 run bossbar set extinction:timer value 54
execute if score #tick ext_tick matches 5761..6000 run bossbar set extinction:timer value 52
execute if score #tick ext_tick matches 6001..7200 run bossbar set extinction:timer value 50
execute if score #tick ext_tick matches 7201..8400 run bossbar set extinction:timer value 42
execute if score #tick ext_tick matches 8401..9600 run bossbar set extinction:timer value 34
execute if score #tick ext_tick matches 9601..10800 run bossbar set extinction:timer value 26
execute if score #tick ext_tick matches 10801..12000 run bossbar set extinction:timer value 20
execute if score #tick ext_tick matches 12001..14400 run bossbar set extinction:timer value 14
execute if score #tick ext_tick matches 14401..16800 run bossbar set extinction:timer value 8
execute if score #tick ext_tick matches 16801..19200 run bossbar set extinction:timer value 4
execute if score #tick ext_tick matches 19201..21600 run bossbar set extinction:timer value 2
execute if score #tick ext_tick matches 21601.. run bossbar set extinction:timer value 1
