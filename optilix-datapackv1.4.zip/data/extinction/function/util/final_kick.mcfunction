# Final kick — no global message beforehand, just booted
kick @a WORLD DATA LOST.
scoreboard players set #running ext_running 0
bossbar set extinction:timer visible false
bossbar set extinction:phase visible false
