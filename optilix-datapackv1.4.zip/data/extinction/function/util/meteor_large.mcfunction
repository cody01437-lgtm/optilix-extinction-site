# === LARGE METEOR ===
summon minecraft:falling_block ~ ~60 ~ {BlockState:{Name:"minecraft:magma_block"},Time:1}
summon minecraft:falling_block ~2 ~62 ~2 {BlockState:{Name:"minecraft:obsidian"},Time:1}
summon minecraft:falling_block ~-2 ~61 ~ {BlockState:{Name:"minecraft:magma_block"},Time:1}
summon minecraft:falling_block ~ ~63 ~-2 {BlockState:{Name:"minecraft:obsidian"},Time:1}
summon minecraft:falling_block ~3 ~60 ~-1 {BlockState:{Name:"minecraft:magma_block"},Time:1}
summon minecraft:falling_block ~-3 ~64 ~3 {BlockState:{Name:"minecraft:obsidian"},Time:1}
summon minecraft:falling_block ~1 ~65 ~-3 {BlockState:{Name:"minecraft:magma_block"},Time:1}
summon minecraft:falling_block ~-1 ~62 ~4 {BlockState:{Name:"minecraft:obsidian"},Time:1}
summon minecraft:falling_block ~4 ~66 ~1 {BlockState:{Name:"minecraft:magma_block"},Time:1}
summon minecraft:falling_block ~-4 ~60 ~-1 {BlockState:{Name:"minecraft:obsidian"},Time:1}
summon minecraft:falling_block ~2 ~68 ~-4 {BlockState:{Name:"minecraft:magma_block"},Time:1}
summon minecraft:falling_block ~-2 ~70 ~2 {BlockState:{Name:"minecraft:obsidian"},Time:1}
playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 2 0.4
playsound minecraft:entity.lightning_bolt.thunder ambient @a ~ ~ ~ 2 0.5
playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 1 0.3
summon minecraft:lightning_bolt ~ ~ ~
summon minecraft:lightning_bolt ~3 ~ ~-3
summon minecraft:lightning_bolt ~-3 ~ ~3
effect give @a minecraft:nausea 4 1 true
fill ~-3 ~1 ~-3 ~3 ~1 ~3 minecraft:fire
