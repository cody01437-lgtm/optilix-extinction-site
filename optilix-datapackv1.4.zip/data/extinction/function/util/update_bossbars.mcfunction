# === UPDATE BOSSBARS ===
# Timer bar drains across the day — value = current tick (max=24000, so it fills then we invert visually via name)
# We can't do execute store into bossbar directly, so we update name + phase bar here

# Phase bar value — set explicitly per phase
execute if score #phase ext_phase matches 1 run bossbar set extinction:phase value 1
execute if score #phase ext_phase matches 2 run bossbar set extinction:phase value 2
execute if score #phase ext_phase matches 3 run bossbar set extinction:phase value 3
execute if score #phase ext_phase matches 4 run bossbar set extinction:phase value 4
execute if score #phase ext_phase matches 5 run bossbar set extinction:phase value 5
execute if score #phase ext_phase matches 6 run bossbar set extinction:phase value 6
execute if score #phase ext_phase matches 7 run bossbar set extinction:phase value 7
execute if score #phase ext_phase matches 8 run bossbar set extinction:phase value 8
execute if score #phase ext_phase matches 9 run bossbar set extinction:phase value 9
execute if score #phase ext_phase matches 10 run bossbar set extinction:phase value 10

# Timer bar name = phase label
execute if score #phase ext_phase matches 1 run bossbar set extinction:timer name {"text":"⬛ PHASE I","color":"gray","bold":false}
execute if score #phase ext_phase matches 2 run bossbar set extinction:timer name {"text":"⬛⬛ PHASE II","color":"gray","bold":false}
execute if score #phase ext_phase matches 3 run bossbar set extinction:timer name {"text":"⬛⬛⬛ PHASE III","color":"gold","bold":false}
execute if score #phase ext_phase matches 4 run bossbar set extinction:timer name {"text":"⬛⬛⬛⬛ PHASE IV","color":"gold","bold":false}
execute if score #phase ext_phase matches 5 run bossbar set extinction:timer name {"text":"⬛⬛⬛⬛⬛ PHASE V","color":"red","bold":false}
execute if score #phase ext_phase matches 6 run bossbar set extinction:timer name {"text":"⬛⬛⬛⬛⬛⬛ PHASE VI","color":"dark_purple","bold":true}
execute if score #phase ext_phase matches 7 run bossbar set extinction:timer name {"text":"⬛⬛⬛⬛⬛⬛⬛ PHASE VII","color":"light_purple","bold":true}
execute if score #phase ext_phase matches 8 run bossbar set extinction:timer name {"text":"⬛⬛⬛⬛⬛⬛⬛⬛ PHASE VIII  ☠","color":"dark_red","bold":true}
execute if score #phase ext_phase matches 9 run bossbar set extinction:timer name {"text":"☠ ☠ ☠  PHASE IX  ☠ ☠ ☠","color":"dark_red","bold":true}
execute if score #phase ext_phase matches 10 run bossbar set extinction:timer name {"text":"▓▓▓▓▓▓▓▓▓▓ EXTINCTION","color":"dark_red","bold":true}

# Timer bar color per phase bracket
execute if score #phase ext_phase matches 1..2 run bossbar set extinction:timer color white
execute if score #phase ext_phase matches 3..4 run bossbar set extinction:timer color yellow
execute if score #phase ext_phase matches 5..6 run bossbar set extinction:timer color red
execute if score #phase ext_phase matches 7..8 run bossbar set extinction:timer color purple
execute if score #phase ext_phase matches 9..10 run bossbar set extinction:timer color red
