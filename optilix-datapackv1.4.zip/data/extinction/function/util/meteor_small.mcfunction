# === SMALL METEOR ===
summon minecraft:falling_block ~ ~40 ~ {BlockState:{Name:"minecraft:magma_block"},Time:1}
summon minecraft:falling_block ~1 ~42 ~1 {BlockState:{Name:"minecraft:obsidian"},Time:1}
summon minecraft:falling_block ~-1 ~41 ~ {BlockState:{Name:"minecraft:magma_block"},Time:1}
summon minecraft:falling_block ~ ~43 ~-1 {BlockState:{Name:"minecraft:obsidian"},Time:1}
summon minecraft:falling_block ~2 ~40 ~-2 {BlockState:{Name:"minecraft:magma_block"},Time:1}
summon minecraft:falling_block ~-2 ~44 ~2 {BlockState:{Name:"minecraft:magma_block"},Time:1}
playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 1.5 0.6
playsound minecraft:entity.lightning_bolt.thunder ambient @a ~ ~ ~ 1 0.8
summon minecraft:lightning_bolt ~ ~ ~
