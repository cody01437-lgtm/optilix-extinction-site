# === EXTINCTION DATAPACK — LOAD ===
scoreboard objectives add ext_phase dummy "Extinction Phase"
scoreboard objectives add ext_day dummy "Day in Phase"
scoreboard objectives add ext_tick dummy "Tick Counter"
scoreboard objectives add ext_running dummy "Running"
scoreboard objectives add ext_admin dummy "Admin"

execute unless score #phase ext_phase matches 0.. run scoreboard players set #phase ext_phase 0
execute unless score #day ext_day matches 0.. run scoreboard players set #day ext_day 0
execute unless score #tick ext_tick matches 0.. run scoreboard players set #tick ext_tick 0
execute unless score #running ext_running matches 0.. run scoreboard players set #running ext_running 0

# Bossbars — one silent ominous timer, always visible once event starts
bossbar add extinction:timer " "
bossbar set extinction:timer color red
bossbar set extinction:timer style progress
bossbar set extinction:timer max 24000
bossbar set extinction:timer value 24000
bossbar set extinction:timer visible false

bossbar add extinction:phase " "
bossbar set extinction:phase color purple
bossbar set extinction:phase style notched_10
bossbar set extinction:phase max 10
bossbar set extinction:phase value 0
bossbar set extinction:phase visible false
scoreboard objectives add ext_subtick dummy
