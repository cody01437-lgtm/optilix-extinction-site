# === MAIN TICK ROUTER ===
execute if score #running ext_running matches 1 run scoreboard players add #tick ext_tick 1
execute if score #running ext_running matches 1 run scoreboard players add #subtick ext_tick 1
execute if score #running ext_running matches 1 if score #tick ext_tick matches 24000.. run function extinction:tick/advance_day

# Update bossbars every 20 ticks (1 second) using subtick
execute if score #running ext_running matches 1 if score #subtick ext_tick matches 20.. run function extinction:util/update_bossbars
execute if score #running ext_running matches 1 if score #subtick ext_tick matches 20.. run scoreboard players set #subtick ext_tick 0

# Phase routing
execute if score #phase ext_phase matches 1 run function extinction:phase/p1_tick
execute if score #phase ext_phase matches 2 run function extinction:phase/p2_tick
execute if score #phase ext_phase matches 3 run function extinction:phase/p3_tick
execute if score #phase ext_phase matches 4 run function extinction:phase/p4_tick
execute if score #phase ext_phase matches 5 run function extinction:phase/p5_tick
execute if score #phase ext_phase matches 6 run function extinction:phase/p6_tick
execute if score #phase ext_phase matches 7 run function extinction:phase/p7_tick
execute if score #phase ext_phase matches 8 run function extinction:phase/p8_tick
execute if score #phase ext_phase matches 9 run function extinction:phase/p9_tick
execute if score #phase ext_phase matches 10 run function extinction:phase/p10_tick
