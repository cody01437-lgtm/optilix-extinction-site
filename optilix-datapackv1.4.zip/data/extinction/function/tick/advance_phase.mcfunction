# === ADVANCE PHASE ===
scoreboard players add #phase ext_phase 1
scoreboard players set #day ext_day 1
scoreboard players set #tick ext_tick 0

execute if score #phase ext_phase matches 1 run function extinction:phase/p1_start
execute if score #phase ext_phase matches 2 run function extinction:phase/p2_start
execute if score #phase ext_phase matches 3 run function extinction:phase/p3_start
execute if score #phase ext_phase matches 4 run function extinction:phase/p4_start
execute if score #phase ext_phase matches 5 run function extinction:phase/p5_start
execute if score #phase ext_phase matches 6 run function extinction:phase/p6_start
execute if score #phase ext_phase matches 7 run function extinction:phase/p7_start
execute if score #phase ext_phase matches 8 run function extinction:phase/p8_start
execute if score #phase ext_phase matches 9 run function extinction:phase/p9_start
execute if score #phase ext_phase matches 10 run function extinction:phase/p10_start
