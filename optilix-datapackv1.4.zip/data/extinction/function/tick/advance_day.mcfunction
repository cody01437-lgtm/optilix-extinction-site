# === ADVANCE DAY ===
scoreboard players set #tick ext_tick 0
scoreboard players add #day ext_day 1

# Reset timer bossbar to full
bossbar set extinction:timer value 24000

# Advance phase after day ends
execute if score #day ext_day matches 2.. run function extinction:tick/advance_phase
