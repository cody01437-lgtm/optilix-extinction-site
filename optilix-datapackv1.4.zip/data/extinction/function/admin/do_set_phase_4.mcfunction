scoreboard players set #phase ext_phase 4
scoreboard players set #day ext_day 1
scoreboard players set #tick ext_tick 0
scoreboard players set #running ext_running 1
bossbar set extinction:timer visible true
bossbar set extinction:phase visible true
function extinction:phase/p4_start
tellraw @s {"text":"[EXTINCTION] Jumped to Phase 4.","color":"gray"}
