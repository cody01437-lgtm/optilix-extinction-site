scoreboard players set #phase ext_phase 1
scoreboard players set #day ext_day 1
scoreboard players set #tick ext_tick 0
scoreboard players set #running ext_running 1
bossbar set extinction:timer name {"text":"⬛ PHASE I","color":"gray","bold":false}
bossbar set extinction:timer color white
bossbar set extinction:timer value 24000
bossbar set extinction:timer visible true
bossbar set extinction:phase color white
bossbar set extinction:phase value 1
bossbar set extinction:phase visible true
function extinction:phase/p1_start
tellraw @s {"text":"[EXTINCTION] Jumped to Phase 1.","color":"gray"}
