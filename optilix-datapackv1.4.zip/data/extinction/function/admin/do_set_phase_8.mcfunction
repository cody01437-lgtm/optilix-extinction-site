scoreboard players set #phase ext_phase 8
scoreboard players set #day ext_day 1
scoreboard players set #tick ext_tick 0
scoreboard players set #running ext_running 1
bossbar set extinction:timer visible true
bossbar set extinction:phase visible true
function extinction:phase/p8_start
tellraw @s {"text":"[EXTINCTION] Jumped to Phase 8.","color":"gray"}
