# Run this as the player you want to grant: /function extinction:admin/grant_admin
scoreboard players set @s ext_admin 1
tellraw @s {"text":"[OPTILIX] Admin access granted.","color":"green"}
