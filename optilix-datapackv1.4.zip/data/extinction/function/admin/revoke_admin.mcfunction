scoreboard players set @s ext_admin 0
tellraw @s {"text":"[OPTILIX] Admin access revoked.","color":"gray"}
