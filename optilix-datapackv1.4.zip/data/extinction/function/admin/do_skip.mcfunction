scoreboard players set #tick ext_tick 0
scoreboard players set #day ext_day 1
function extinction:tick/advance_phase
tellraw @s {"text":"[EXTINCTION] Skipped to next phase.","color":"gray"}
