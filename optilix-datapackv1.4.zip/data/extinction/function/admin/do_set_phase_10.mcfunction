scoreboard players set #phase ext_phase 10
scoreboard players set #day ext_day 1
scoreboard players set #tick ext_tick 0
scoreboard players set #running ext_running 1
bossbar set extinction:timer visible true
bossbar set extinction:phase visible true
function extinction:phase/p10_start
tellraw @s {"text":"[EXTINCTION] Jumped to Phase 10.","color":"gray"}
