scoreboard players set #running ext_running 0
scoreboard players set #phase ext_phase 0
scoreboard players set #day ext_day 0
scoreboard players set #tick ext_tick 0
bossbar set extinction:timer visible false
bossbar set extinction:phase visible false
effect clear @a
kill @e[type=minecraft:wither]
kill @e[type=minecraft:phantom]
kill @e[type=minecraft:ghast]
time set day
tellraw @s {"text":"[EXTINCTION] Event stopped and reset.","color":"gray"}
scoreboard players set #subtick ext_tick 0
