execute unless score @s ext_admin matches 1.. run tellraw @s {"text":"[EXTINCTION] You do not have permission to use this command.","color":"red"}
execute if score @s ext_admin matches 1.. run function extinction:admin/do_set_phase_4
