# === ADMIN: START ===
# Guard: only runs if caller has ext_admin score (set manually by server owner)
execute unless score @s ext_admin matches 1.. run tellraw @s {"text":"[EXTINCTION] You do not have permission to use this command.","color":"red"}
execute if score @s ext_admin matches 1.. run function extinction:admin/do_start
