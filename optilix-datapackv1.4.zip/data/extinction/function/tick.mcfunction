# === MAIN TICK ===
# Only run if event is active
execute if score #running ext_running matches 1 run function extinction:tick/router
