# Phase 10 is handled entirely by p10_start + the scheduled final_kick.
# Nothing runs here.
