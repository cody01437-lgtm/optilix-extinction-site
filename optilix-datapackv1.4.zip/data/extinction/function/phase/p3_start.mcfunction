# === PHASE 3 START — The Sky Lies ===
bossbar set extinction:timer color red
bossbar set extinction:phase color red
time set night
playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 0.5 0.5
playsound minecraft:ambient.cave ambient @a ~ ~ ~ 1 0.9
