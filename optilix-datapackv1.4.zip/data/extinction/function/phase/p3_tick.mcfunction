# === PHASE 3 TICK ===
execute if score #tick ext_tick matches 0 run effect give @a minecraft:darkness 30 2 true
execute if score #tick ext_tick matches 6000 run effect give @a minecraft:darkness 30 2 true
execute if score #tick ext_tick matches 12000 run effect give @a minecraft:darkness 30 2 true
execute if score #tick ext_tick matches 18000 run effect give @a minecraft:darkness 30 2 true

# Crops continue dying
execute if score #tick ext_tick matches 7000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:wheat
execute if score #tick ext_tick matches 7000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:carrots
execute if score #tick ext_tick matches 7000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:potatoes
execute if score #tick ext_tick matches 7000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:beetroots
execute if score #tick ext_tick matches 7000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:sugar_cane

# Time desync
execute if score #tick ext_tick matches 6000 run time set 18000
execute if score #tick ext_tick matches 12000 run time set 6000
execute if score #tick ext_tick matches 18000 run time set 18000

# Phantoms
execute if score #tick ext_tick matches 2000 run execute as @a at @s run summon minecraft:phantom ~ ~20 ~
execute if score #tick ext_tick matches 5000 run execute as @a at @s run summon minecraft:phantom ~5 ~15 ~5
execute if score #tick ext_tick matches 8000 run execute as @a at @s run summon minecraft:phantom ~-5 ~18 ~
execute if score #tick ext_tick matches 11000 run execute as @a at @s run summon minecraft:phantom ~ ~22 ~-5
execute if score #tick ext_tick matches 15000 run execute as @a at @s run summon minecraft:phantom ~ ~20 ~
execute if score #tick ext_tick matches 20000 run execute as @a at @s run summon minecraft:phantom ~3 ~16 ~-3

# Override spawnpoint
execute if score #tick ext_tick matches 4000 run execute as @a run spawnpoint @s 0 64 0

# Sounds — wither groans mixed with cave
execute if score #tick ext_tick matches 1500 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 0.7 0.4
execute if score #tick ext_tick matches 4000 run playsound minecraft:ambient.cave ambient @a ~ ~ ~ 1 0.9
execute if score #tick ext_tick matches 7500 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 0.6 0.5
execute if score #tick ext_tick matches 10000 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 0.4 0.6
execute if score #tick ext_tick matches 13000 run playsound minecraft:ambient.cave ambient @a ~ ~ ~ 1 0.8
execute if score #tick ext_tick matches 16500 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 0.8 0.3
execute if score #tick ext_tick matches 21000 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 0.5 0.5

# Kill animals
execute if score #tick ext_tick matches 6000 run kill @e[type=minecraft:cow,distance=..50]
execute if score #tick ext_tick matches 10000 run kill @e[type=minecraft:sheep,distance=..50]
execute if score #tick ext_tick matches 16000 run kill @e[type=minecraft:pig,distance=..50]
