# === PHASE 8 TICK — Sirens & Countdown ===
# Silent siren: elder guardian curse + wither every 5 min
execute if score #tick ext_tick matches 0 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 2 0.3
execute if score #tick ext_tick matches 6000 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 2 0.5
execute if score #tick ext_tick matches 6200 run playsound minecraft:entity.wither.spawn ambient @a ~ ~ ~ 1 0.3
execute if score #tick ext_tick matches 12000 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 2 0.3
execute if score #tick ext_tick matches 18000 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 2 0.5
execute if score #tick ext_tick matches 18200 run playsound minecraft:entity.wither.spawn ambient @a ~ ~ ~ 1 0.3

# Extra ambient sounds
execute if score #tick ext_tick matches 2000 run playsound minecraft:entity.wither.shoot ambient @a ~ ~ ~ 1 0.3
execute if score #tick ext_tick matches 4500 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 0.8 0.5
execute if score #tick ext_tick matches 8000 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 1.5 0.4
execute if score #tick ext_tick matches 10000 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 1.5 0.3
execute if score #tick ext_tick matches 14000 run playsound minecraft:entity.wither.shoot ambient @a ~ ~ ~ 1 0.4
execute if score #tick ext_tick matches 16000 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 1 0.5
execute if score #tick ext_tick matches 20000 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 2 0.4
execute if score #tick ext_tick matches 22000 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 2 0.3

# Night forever
execute if score #tick ext_tick matches 0 run time set 18000
execute if score #tick ext_tick matches 6000 run time set 18000
execute if score #tick ext_tick matches 12000 run time set 18000
execute if score #tick ext_tick matches 18000 run time set 18000

# All effects max
execute if score #tick ext_tick matches 0 run effect give @a minecraft:darkness 30 4 true
execute if score #tick ext_tick matches 6000 run effect give @a minecraft:darkness 30 4 true
execute if score #tick ext_tick matches 12000 run effect give @a minecraft:darkness 30 4 true
execute if score #tick ext_tick matches 18000 run effect give @a minecraft:darkness 30 4 true
execute if score #tick ext_tick matches 0 run effect give @a minecraft:hunger 30 2 true
execute if score #tick ext_tick matches 12000 run effect give @a minecraft:hunger 30 2 true
execute if score #tick ext_tick matches 1500 run effect give @a[limit=3,sort=random] minecraft:nausea 6 1 true
execute if score #tick ext_tick matches 7000 run effect give @a[limit=3,sort=random] minecraft:blindness 5 0 true
execute if score #tick ext_tick matches 11000 run effect give @a[limit=2,sort=random] minecraft:levitation 3 0 true
execute if score #tick ext_tick matches 15000 run effect give @a[limit=3,sort=random] minecraft:nausea 5 0 true
execute if score #tick ext_tick matches 20000 run effect give @a[limit=2,sort=random] minecraft:blindness 4 0 true

# Mob buffs max
execute if score #tick ext_tick matches 0 run effect give @e[type=minecraft:zombie,distance=..80] minecraft:strength 60 3 true
execute if score #tick ext_tick matches 0 run effect give @e[type=minecraft:skeleton,distance=..80] minecraft:speed 60 3 true
execute if score #tick ext_tick matches 0 run effect give @e[type=minecraft:creeper,distance=..80] minecraft:speed 60 2 true
execute if score #tick ext_tick matches 0 run effect give @e[type=minecraft:spider,distance=..80] minecraft:speed 60 3 true

# Withers — 3 per cycle
execute if score #tick ext_tick matches 2000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:wither ~ ~5 ~
execute if score #tick ext_tick matches 2000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:wither ~10 ~5 ~10
execute if score #tick ext_tick matches 9000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:wither ~ ~5 ~
execute if score #tick ext_tick matches 9000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:wither ~-10 ~5 ~-10
execute if score #tick ext_tick matches 17000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:wither ~ ~5 ~
execute if score #tick ext_tick matches 17000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:wither ~10 ~5 ~-10

# Meteors — frequent, mix of small and large
execute if score #tick ext_tick matches 1000 run execute as @a at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 3500 run execute as @a[limit=2,sort=random] at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 6000 run execute as @a at @s run function extinction:util/meteor_large
execute if score #tick ext_tick matches 9000 run execute as @a at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 12000 run execute as @a[limit=2,sort=random] at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 14500 run execute as @a at @s run function extinction:util/meteor_large
execute if score #tick ext_tick matches 17000 run execute as @a at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 20000 run execute as @a[limit=2,sort=random] at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 22000 run execute as @a at @s run function extinction:util/meteor_large

# Lightning
execute if score #tick ext_tick matches 3000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:lightning_bolt ~5 ~ ~5
execute if score #tick ext_tick matches 8000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:lightning_bolt ~-5 ~ ~-5
execute if score #tick ext_tick matches 13000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:lightning_bolt ~5 ~ ~-5
execute if score #tick ext_tick matches 19000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:lightning_bolt ~-5 ~ ~5

# Phantom swarm — constant
execute if score #tick ext_tick matches 1000 run execute as @a at @s run summon minecraft:phantom ~ ~20 ~
execute if score #tick ext_tick matches 2500 run execute as @a at @s run summon minecraft:phantom ~5 ~15 ~5
execute if score #tick ext_tick matches 4000 run execute as @a at @s run summon minecraft:phantom ~ ~22 ~
execute if score #tick ext_tick matches 6000 run execute as @a at @s run summon minecraft:phantom ~-5 ~18 ~-5
execute if score #tick ext_tick matches 8000 run execute as @a at @s run summon minecraft:phantom ~ ~20 ~
execute if score #tick ext_tick matches 10000 run execute as @a at @s run summon minecraft:phantom ~3 ~16 ~-3
execute if score #tick ext_tick matches 12000 run execute as @a at @s run summon minecraft:phantom ~ ~22 ~
execute if score #tick ext_tick matches 14000 run execute as @a at @s run summon minecraft:phantom ~-3 ~20 ~3
execute if score #tick ext_tick matches 16000 run execute as @a at @s run summon minecraft:phantom ~ ~18 ~
execute if score #tick ext_tick matches 18000 run execute as @a at @s run summon minecraft:phantom ~5 ~20 ~-5
execute if score #tick ext_tick matches 20000 run execute as @a at @s run summon minecraft:phantom ~ ~22 ~
execute if score #tick ext_tick matches 22000 run execute as @a at @s run summon minecraft:phantom ~-5 ~15 ~5

# Sinkholes start appearing
execute if score #tick ext_tick matches 5000 run execute as @a[limit=1,sort=random] at @s run fill ~-3 ~-1 ~-3 ~3 ~-4 ~3 minecraft:air replace minecraft:grass_block
execute if score #tick ext_tick matches 5000 run execute as @a[limit=1,sort=random] at @s run fill ~-3 ~-1 ~-3 ~3 ~-4 ~3 minecraft:air replace minecraft:dirt
execute if score #tick ext_tick matches 16000 run execute as @a[limit=1,sort=random] at @s run fill ~-3 ~-1 ~-3 ~3 ~-4 ~3 minecraft:air replace minecraft:grass_block
execute if score #tick ext_tick matches 16000 run execute as @a[limit=1,sort=random] at @s run fill ~-3 ~-1 ~-3 ~3 ~-4 ~3 minecraft:air replace minecraft:dirt
