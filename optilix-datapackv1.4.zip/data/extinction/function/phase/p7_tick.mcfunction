# === PHASE 7 TICK — Reality Breaking ===
execute if score #tick ext_tick matches 0 run effect give @a minecraft:darkness 30 4 true
execute if score #tick ext_tick matches 6000 run effect give @a minecraft:darkness 30 4 true
execute if score #tick ext_tick matches 12000 run effect give @a minecraft:darkness 30 4 true
execute if score #tick ext_tick matches 18000 run effect give @a minecraft:darkness 30 4 true

# Random debuffs on random players — irregular timing
execute if score #tick ext_tick matches 800 run effect give @a[limit=3,sort=random] minecraft:blindness 4 0 true
execute if score #tick ext_tick matches 2300 run effect give @a[limit=2,sort=random] minecraft:nausea 6 1 true
execute if score #tick ext_tick matches 4100 run effect give @a[limit=4,sort=random] minecraft:blindness 3 0 true
execute if score #tick ext_tick matches 6700 run effect give @a[limit=1,sort=random] minecraft:levitation 3 0 true
execute if score #tick ext_tick matches 8500 run effect give @a[limit=3,sort=random] minecraft:nausea 5 0 true
execute if score #tick ext_tick matches 10200 run effect give @a[limit=2,sort=random] minecraft:blindness 5 0 true
execute if score #tick ext_tick matches 12900 run effect give @a[limit=3,sort=random] minecraft:nausea 4 1 true
execute if score #tick ext_tick matches 14600 run effect give @a[limit=1,sort=random] minecraft:levitation 4 0 true
execute if score #tick ext_tick matches 16300 run effect give @a[limit=2,sort=random] minecraft:blindness 3 0 true
execute if score #tick ext_tick matches 18800 run effect give @a[limit=3,sort=random] minecraft:nausea 5 1 true
execute if score #tick ext_tick matches 21000 run effect give @a[limit=4,sort=random] minecraft:blindness 4 0 true

# Time skips chaotic
execute if score #tick ext_tick matches 2000 run time set 18000
execute if score #tick ext_tick matches 4000 run time set 6000
execute if score #tick ext_tick matches 7000 run time set 18000
execute if score #tick ext_tick matches 9500 run time set 0
execute if score #tick ext_tick matches 11000 run time set 18000
execute if score #tick ext_tick matches 14000 run time set 6000
execute if score #tick ext_tick matches 17000 run time set 18000
execute if score #tick ext_tick matches 20000 run time set 0

# Hunger + corruption
execute if score #tick ext_tick matches 0 run effect give @a minecraft:hunger 30 1 true
execute if score #tick ext_tick matches 12000 run effect give @a minecraft:hunger 30 1 true

# Mob buffs escalate
execute if score #tick ext_tick matches 0 run effect give @e[type=minecraft:zombie,distance=..80] minecraft:strength 60 2 true
execute if score #tick ext_tick matches 0 run effect give @e[type=minecraft:skeleton,distance=..80] minecraft:speed 60 2 true
execute if score #tick ext_tick matches 0 run effect give @e[type=minecraft:creeper,distance=..80] minecraft:speed 60 2 true
execute if score #tick ext_tick matches 0 run effect give @e[type=minecraft:spider,distance=..80] minecraft:speed 60 3 true

# Withers — phase 7 starts spamming them
execute if score #tick ext_tick matches 3000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:wither ~ ~5 ~
execute if score #tick ext_tick matches 10000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:wither ~ ~5 ~
execute if score #tick ext_tick matches 18000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:wither ~ ~5 ~

# Meteors frequent + lightning
execute if score #tick ext_tick matches 2500 run execute as @a at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 6000 run execute as @a[limit=2,sort=random] at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 10000 run execute as @a at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 14000 run execute as @a[limit=2,sort=random] at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 20000 run execute as @a at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 4000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:lightning_bolt ~5 ~ ~-5
execute if score #tick ext_tick matches 11000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:lightning_bolt ~-5 ~ ~5
execute if score #tick ext_tick matches 19000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:lightning_bolt ~3 ~ ~3

# Phantom swarm intensifies
execute if score #tick ext_tick matches 1500 run execute as @a at @s run summon minecraft:phantom ~ ~20 ~
execute if score #tick ext_tick matches 3000 run execute as @a at @s run summon minecraft:phantom ~5 ~15 ~5
execute if score #tick ext_tick matches 5000 run execute as @a at @s run summon minecraft:phantom ~ ~22 ~
execute if score #tick ext_tick matches 8000 run execute as @a at @s run summon minecraft:phantom ~-5 ~18 ~-5
execute if score #tick ext_tick matches 11000 run execute as @a at @s run summon minecraft:phantom ~ ~20 ~
execute if score #tick ext_tick matches 14000 run execute as @a at @s run summon minecraft:phantom ~3 ~16 ~-3
execute if score #tick ext_tick matches 17000 run execute as @a at @s run summon minecraft:phantom ~ ~22 ~
execute if score #tick ext_tick matches 21000 run execute as @a at @s run summon minecraft:phantom ~-3 ~20 ~3

# Sounds — chaotic mix
execute if score #tick ext_tick matches 500 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 1 0.5
execute if score #tick ext_tick matches 2000 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 1 0.3
execute if score #tick ext_tick matches 4500 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 1 0.5
execute if score #tick ext_tick matches 6500 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 0.9 0.4
execute if score #tick ext_tick matches 9000 run playsound minecraft:entity.wither.shoot ambient @a ~ ~ ~ 0.8 0.3
execute if score #tick ext_tick matches 11500 run playsound minecraft:entity.lightning_bolt.thunder ambient @a ~ ~ ~ 1 0.5
execute if score #tick ext_tick matches 13500 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 1 0.6
execute if score #tick ext_tick matches 16000 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 1 0.4
execute if score #tick ext_tick matches 19000 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 1.5 0.5
execute if score #tick ext_tick matches 22000 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 0.8 0.5
