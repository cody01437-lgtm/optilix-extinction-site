# === PHASE 9 TICK — THE END OF ALL (short but unplayable) === 
#lmao if ur checking these files, yes they are all ai slop but whatever lol.
# Max effects constant
execute if score #tick ext_tick matches 0 run effect give @a minecraft:darkness 30 4 true
execute if score #tick ext_tick matches 100 run effect give @a minecraft:nausea 30 2 true
execute if score #tick ext_tick matches 200 run effect give @a minecraft:weakness 30 3 true
execute if score #tick ext_tick matches 300 run effect give @a minecraft:hunger 30 3 true
execute if score #tick ext_tick matches 400 run effect give @a minecraft:blindness 30 1 true

# Withers — constant spam, ALL players targeted
execute if score #tick ext_tick matches 400 run execute as @a at @s run summon minecraft:wither ~ ~5 ~
execute if score #tick ext_tick matches 400 run execute as @a at @s run summon minecraft:wither ~10 ~5 ~10
execute if score #tick ext_tick matches 1500 run execute as @a at @s run summon minecraft:wither ~-10 ~5 ~-10
execute if score #tick ext_tick matches 1500 run execute as @a at @s run summon minecraft:wither ~10 ~5 ~-10
execute if score #tick ext_tick matches 3000 run execute as @a at @s run summon minecraft:wither ~ ~5 ~
execute if score #tick ext_tick matches 3000 run execute as @a at @s run summon minecraft:wither ~15 ~5 ~
execute if score #tick ext_tick matches 5000 run execute as @a at @s run summon minecraft:wither ~ ~5 ~
execute if score #tick ext_tick matches 5000 run execute as @a at @s run summon minecraft:wither ~ ~5 ~15
execute if score #tick ext_tick matches 7000 run execute as @a at @s run summon minecraft:wither ~-15 ~5 ~
execute if score #tick ext_tick matches 7000 run execute as @a at @s run summon minecraft:wither ~ ~5 ~-15
execute if score #tick ext_tick matches 9000 run execute as @a at @s run summon minecraft:ghast ~ ~5 ~
execute if score #tick ext_tick matches 9000 run execute as @a at @s run summon minecraft:ghast ~10 ~5 ~10
execute if score #tick ext_tick matches 11000 run execute as @a at @s run summon minecraft:ghast ~-10 ~5 ~10
execute if score #tick ext_tick matches 400 run execute as @a at @s run summon minecraft:ghast ~ ~5 ~
execute if score #tick ext_tick matches 400 run execute as @a at @s run summon minecraft:ghast ~10 ~5 ~10
execute if score #tick ext_tick matches 1500 run execute as @a at @s run summon minecraft:ghast ~-10 ~5 ~-10
execute if score #tick ext_tick matches 1500 run execute as @a at @s run summon minecraft:ghast ~10 ~5 ~-10
execute if score #tick ext_tick matches 3000 run execute as @a at @s run summon minecraft:ghast ~ ~5 ~

# Large meteors constant
execute if score #tick ext_tick matches 600 run execute as @a at @s run function extinction:util/meteor_large
execute if score #tick ext_tick matches 1800 run execute as @a at @s run function extinction:util/meteor_large
execute if score #tick ext_tick matches 3200 run execute as @a at @s run function extinction:util/meteor_large
execute if score #tick ext_tick matches 4800 run execute as @a at @s run function extinction:util/meteor_large
execute if score #tick ext_tick matches 6500 run execute as @a at @s run function extinction:util/meteor_large
execute if score #tick ext_tick matches 8200 run execute as @a at @s run function extinction:util/meteor_large
execute if score #tick ext_tick matches 10000 run execute as @a at @s run function extinction:util/meteor_large
execute if score #tick ext_tick matches 12000 run execute as @a at @s run function extinction:util/meteor_large

# Lightning every few seconds everywhere
execute if score #tick ext_tick matches 500 run execute as @a at @s run summon minecraft:lightning_bolt ~5 ~ ~5
execute if score #tick ext_tick matches 500 run execute as @a at @s run summon minecraft:lightning_bolt ~-5 ~ ~-5
execute if score #tick ext_tick matches 1000 run execute as @a at @s run summon minecraft:lightning_bolt ~5 ~ ~-5
execute if score #tick ext_tick matches 1500 run execute as @a at @s run summon minecraft:lightning_bolt ~-5 ~ ~5
execute if score #tick ext_tick matches 2000 run execute as @a at @s run summon minecraft:lightning_bolt ~8 ~ ~
execute if score #tick ext_tick matches 2500 run execute as @a at @s run summon minecraft:lightning_bolt ~ ~ ~8
execute if score #tick ext_tick matches 3000 run execute as @a at @s run summon minecraft:lightning_bolt ~-8 ~ ~
execute if score #tick ext_tick matches 3500 run execute as @a at @s run summon minecraft:lightning_bolt ~ ~ ~-8
execute if score #tick ext_tick matches 4000 run execute as @a at @s run summon minecraft:lightning_bolt ~5 ~ ~5
execute if score #tick ext_tick matches 5000 run execute as @a at @s run summon minecraft:lightning_bolt ~-5 ~ ~-5
execute if score #tick ext_tick matches 6000 run execute as @a at @s run summon minecraft:lightning_bolt ~5 ~ ~-5
execute if score #tick ext_tick matches 7000 run execute as @a at @s run summon minecraft:lightning_bolt ~-5 ~ ~5
execute if score #tick ext_tick matches 8000 run execute as @a at @s run summon minecraft:lightning_bolt ~10 ~ ~10
execute if score #tick ext_tick matches 9000 run execute as @a at @s run summon minecraft:lightning_bolt ~-10 ~ ~-10

# Phantom swarm — overwhelming
execute if score #tick ext_tick matches 200 run execute as @a at @s run summon minecraft:phantom ~ ~20 ~
execute if score #tick ext_tick matches 400 run execute as @a at @s run summon minecraft:phantom ~5 ~15 ~5
execute if score #tick ext_tick matches 600 run execute as @a at @s run summon minecraft:phantom ~-5 ~22 ~-5
execute if score #tick ext_tick matches 800 run execute as @a at @s run summon minecraft:phantom ~ ~18 ~
execute if score #tick ext_tick matches 1000 run execute as @a at @s run summon minecraft:phantom ~3 ~20 ~-3
execute if score #tick ext_tick matches 1500 run execute as @a at @s run summon minecraft:phantom ~ ~22 ~
execute if score #tick ext_tick matches 2000 run execute as @a at @s run summon minecraft:phantom ~-3 ~16 ~3
execute if score #tick ext_tick matches 2500 run execute as @a at @s run summon minecraft:phantom ~ ~20 ~
execute if score #tick ext_tick matches 3000 run execute as @a at @s run summon minecraft:phantom ~5 ~18 ~5
execute if score #tick ext_tick matches 4000 run execute as @a at @s run summon minecraft:phantom ~ ~22 ~
execute if score #tick ext_tick matches 5000 run execute as @a at @s run summon minecraft:phantom ~-5 ~20 ~-5
execute if score #tick ext_tick matches 6000 run execute as @a at @s run summon minecraft:phantom ~ ~18 ~
execute if score #tick ext_tick matches 7000 run execute as @a at @s run summon minecraft:phantom ~3 ~22 ~-3
execute if score #tick ext_tick matches 8000 run execute as @a at @s run summon minecraft:phantom ~ ~20 ~

# Sinkholes opening everywhere
execute if score #tick ext_tick matches 1000 run execute as @a at @s run fill ~-4 ~-1 ~-4 ~4 ~-6 ~4 minecraft:air replace minecraft:grass_block
execute if score #tick ext_tick matches 1000 run execute as @a at @s run fill ~-4 ~-1 ~-4 ~4 ~-6 ~4 minecraft:air replace minecraft:dirt
execute if score #tick ext_tick matches 1000 run execute as @a at @s run fill ~-4 ~-1 ~-4 ~4 ~-6 ~4 minecraft:air replace minecraft:stone
execute if score #tick ext_tick matches 5000 run execute as @a at @s run fill ~-4 ~-1 ~-4 ~4 ~-6 ~4 minecraft:air replace minecraft:grass_block
execute if score #tick ext_tick matches 5000 run execute as @a at @s run fill ~-4 ~-1 ~-4 ~4 ~-6 ~4 minecraft:air replace minecraft:dirt
execute if score #tick ext_tick matches 9000 run execute as @a at @s run fill ~-4 ~-1 ~-4 ~4 ~-6 ~4 minecraft:air replace minecraft:stone

# Fire everywhere
execute if score #tick ext_tick matches 2000 run execute as @a[limit=1,sort=random] at @s run fill ~-10 ~1 ~-10 ~10 ~1 ~10 minecraft:fire
execute if score #tick ext_tick matches 6000 run execute as @a[limit=1,sort=random] at @s run fill ~-10 ~1 ~-10 ~10 ~1 ~10 minecraft:fire
execute if score #tick ext_tick matches 10000 run execute as @a[limit=1,sort=random] at @s run fill ~-10 ~1 ~-10 ~10 ~1 ~10 minecraft:fire

# Night stays
execute if score #tick ext_tick matches 0 run time set 18000
execute if score #tick ext_tick matches 6000 run time set 18000
execute if score #tick ext_tick matches 12000 run time set 18000

# Sounds — overwhelming
execute if score #tick ext_tick matches 0 run playsound minecraft:entity.wither.death ambient @a ~ ~ ~ 2 0.2
execute if score #tick ext_tick matches 300 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 2 0.4
execute if score #tick ext_tick matches 700 run playsound minecraft:entity.lightning_bolt.thunder ambient @a ~ ~ ~ 2 0.5
execute if score #tick ext_tick matches 1200 run playsound minecraft:entity.wither.shoot ambient @a ~ ~ ~ 2 0.3
execute if score #tick ext_tick matches 1800 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 2 0.5
execute if score #tick ext_tick matches 2400 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 2 0.4
execute if score #tick ext_tick matches 3000 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 2 0.3
execute if score #tick ext_tick matches 3600 run playsound minecraft:entity.lightning_bolt.thunder ambient @a ~ ~ ~ 2 0.5
execute if score #tick ext_tick matches 4200 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 2 0.4
execute if score #tick ext_tick matches 4800 run playsound minecraft:entity.wither.shoot ambient @a ~ ~ ~ 2 0.3
execute if score #tick ext_tick matches 5400 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 2 0.5
execute if score #tick ext_tick matches 6000 run playsound minecraft:entity.wither.death ambient @a ~ ~ ~ 2 0.2
execute if score #tick ext_tick matches 6600 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 2 0.4
execute if score #tick ext_tick matches 7200 run playsound minecraft:entity.lightning_bolt.thunder ambient @a ~ ~ ~ 2 0.5
execute if score #tick ext_tick matches 7800 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 2 0.3
execute if score #tick ext_tick matches 8400 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 2 0.5
execute if score #tick ext_tick matches 9000 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 2 0.4
execute if score #tick ext_tick matches 9600 run playsound minecraft:entity.wither.shoot ambient @a ~ ~ ~ 2 0.3
execute if score #tick ext_tick matches 10200 run playsound minecraft:entity.lightning_bolt.thunder ambient @a ~ ~ ~ 2 0.5
execute if score #tick ext_tick matches 10800 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 2 0.4
execute if score #tick ext_tick matches 11400 run playsound minecraft:entity.wither.death ambient @a ~ ~ ~ 2 0.2
execute if score #tick ext_tick matches 12000 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 2 0.5
