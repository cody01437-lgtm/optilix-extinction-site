# === PHASE 4 TICK ===
execute if score #tick ext_tick matches 0 run effect give @a minecraft:darkness 30 3 true
execute if score #tick ext_tick matches 6000 run effect give @a minecraft:darkness 30 3 true
execute if score #tick ext_tick matches 12000 run effect give @a minecraft:darkness 30 3 true
execute if score #tick ext_tick matches 18000 run effect give @a minecraft:darkness 30 3 true

# Sinkholes — hit all nearby block types properly
execute if score #tick ext_tick matches 3000 run execute as @a[limit=1,sort=random] at @s run fill ~-3 ~-1 ~-3 ~3 ~-4 ~3 minecraft:air replace minecraft:grass_block
execute if score #tick ext_tick matches 3000 run execute as @a[limit=1,sort=random] at @s run fill ~-3 ~-1 ~-3 ~3 ~-4 ~3 minecraft:air replace minecraft:dirt
execute if score #tick ext_tick matches 3000 run execute as @a[limit=1,sort=random] at @s run fill ~-3 ~-1 ~-3 ~3 ~-4 ~3 minecraft:air replace minecraft:grass_path
execute if score #tick ext_tick matches 7000 run execute as @a[limit=1,sort=random] at @s run fill ~-2 ~-1 ~-2 ~2 ~-5 ~2 minecraft:air replace minecraft:stone
execute if score #tick ext_tick matches 7000 run execute as @a[limit=1,sort=random] at @s run fill ~-2 ~-1 ~-2 ~2 ~-5 ~2 minecraft:air replace minecraft:cobblestone
execute if score #tick ext_tick matches 14000 run execute as @a[limit=1,sort=random] at @s run fill ~-3 ~-1 ~-3 ~3 ~-4 ~3 minecraft:air replace minecraft:grass_block
execute if score #tick ext_tick matches 14000 run execute as @a[limit=1,sort=random] at @s run fill ~-3 ~-1 ~-3 ~3 ~-4 ~3 minecraft:air replace minecraft:dirt
execute if score #tick ext_tick matches 20000 run execute as @a[limit=1,sort=random] at @s run fill ~-2 ~-1 ~-2 ~2 ~-5 ~2 minecraft:air replace minecraft:stone

# Gravel/sand rain
execute if score #tick ext_tick matches 5000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:falling_block ~3 ~8 ~ {BlockState:{Name:"minecraft:gravel"},Time:1}
execute if score #tick ext_tick matches 5000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:falling_block ~-3 ~10 ~2 {BlockState:{Name:"minecraft:gravel"},Time:1}
execute if score #tick ext_tick matches 5000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:falling_block ~ ~9 ~-3 {BlockState:{Name:"minecraft:sand"},Time:1}
execute if score #tick ext_tick matches 10000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:falling_block ~2 ~8 ~4 {BlockState:{Name:"minecraft:gravel"},Time:1}
execute if score #tick ext_tick matches 10000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:falling_block ~-4 ~10 ~-2 {BlockState:{Name:"minecraft:sand"},Time:1}
execute if score #tick ext_tick matches 10000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:falling_block ~1 ~12 ~-1 {BlockState:{Name:"minecraft:gravel"},Time:1}
execute if score #tick ext_tick matches 17000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:falling_block ~-2 ~9 ~3 {BlockState:{Name:"minecraft:gravel"},Time:1}
execute if score #tick ext_tick matches 17000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:falling_block ~4 ~11 ~-4 {BlockState:{Name:"minecraft:sand"},Time:1}

# Tremor nausea
execute if score #tick ext_tick matches 4000 run effect give @a minecraft:nausea 3 0 true
execute if score #tick ext_tick matches 10000 run effect give @a minecraft:nausea 4 0 true
execute if score #tick ext_tick matches 17000 run effect give @a minecraft:nausea 3 0 true

# Rumble + thunder sounds
execute if score #tick ext_tick matches 3000 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 0.5 0.3
execute if score #tick ext_tick matches 5500 run playsound minecraft:entity.lightning_bolt.thunder ambient @a ~ ~ ~ 0.5 0.5
execute if score #tick ext_tick matches 8000 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 0.6 0.3
execute if score #tick ext_tick matches 11000 run playsound minecraft:block.anvil.land ambient @a ~ ~ ~ 1 0.4
execute if score #tick ext_tick matches 14000 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 0.5 0.4
execute if score #tick ext_tick matches 17000 run playsound minecraft:entity.lightning_bolt.thunder ambient @a ~ ~ ~ 0.7 0.5
execute if score #tick ext_tick matches 20000 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 0.6 0.3

# Time desync
execute if score #tick ext_tick matches 8000 run time set 18000
execute if score #tick ext_tick matches 16000 run time set 6000

# Phantoms start
execute if score #tick ext_tick matches 6000 run execute as @a at @s run summon minecraft:phantom ~ ~20 ~
execute if score #tick ext_tick matches 14000 run execute as @a at @s run summon minecraft:phantom ~3 ~18 ~-3
