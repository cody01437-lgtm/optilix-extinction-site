# === PHASE 6 START — Corruption ===
bossbar set extinction:timer color purple
bossbar set extinction:phase color purple
playsound minecraft:entity.wither.spawn ambient @a ~ ~ ~ 1 0.7
playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 1 0.5
effect give @a minecraft:poison 10 0 true
effect give @a minecraft:hunger 10 1 true
