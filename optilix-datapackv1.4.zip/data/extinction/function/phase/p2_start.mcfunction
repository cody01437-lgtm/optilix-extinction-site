# === PHASE 2 START — Environmental Glitches ===
bossbar set extinction:timer color white
bossbar set extinction:phase color white
playsound minecraft:block.beacon.deactivate ambient @a ~ ~ ~ 1 0.5
playsound minecraft:ambient.cave ambient @a ~ ~ ~ 1 0.6
