# === PHASE 6 TICK — Corruption ===
execute if score #tick ext_tick matches 0 run effect give @a minecraft:darkness 30 4 true
execute if score #tick ext_tick matches 6000 run effect give @a minecraft:darkness 30 4 true
execute if score #tick ext_tick matches 12000 run effect give @a minecraft:darkness 30 4 true
execute if score #tick ext_tick matches 18000 run effect give @a minecraft:darkness 30 4 true

# Mutate mobs — every 30s
execute if score #tick ext_tick matches 0 run execute as @e[type=minecraft:zombie,distance=..80] run attribute @s minecraft:generic.max_health base set 40
execute if score #tick ext_tick matches 0 run execute as @e[type=minecraft:skeleton,distance=..80] run attribute @s minecraft:generic.max_health base set 30
execute if score #tick ext_tick matches 0 run execute as @e[type=minecraft:creeper,distance=..80] run attribute @s minecraft:generic.max_health base set 30
execute if score #tick ext_tick matches 0 run execute as @e[type=minecraft:spider,distance=..80] run attribute @s minecraft:generic.max_health base set 25
execute if score #tick ext_tick matches 0 run execute as @e[type=minecraft:witch,distance=..80] run attribute @s minecraft:generic.max_health base set 50
execute if score #tick ext_tick matches 0 run effect give @e[type=minecraft:zombie,distance=..80] minecraft:strength 60 1 true
execute if score #tick ext_tick matches 0 run effect give @e[type=minecraft:skeleton,distance=..80] minecraft:speed 60 1 true
execute if score #tick ext_tick matches 0 run effect give @e[type=minecraft:spider,distance=..80] minecraft:speed 60 2 true
execute if score #tick ext_tick matches 0 run effect give @e[type=minecraft:creeper,distance=..80] minecraft:speed 60 1 true
execute if score #tick ext_tick matches 600 run execute as @e[type=minecraft:zombie,distance=..80] run attribute @s minecraft:generic.max_health base set 40
execute if score #tick ext_tick matches 600 run effect give @e[type=minecraft:zombie,distance=..80] minecraft:strength 60 1 true
execute if score #tick ext_tick matches 600 run effect give @e[type=minecraft:skeleton,distance=..80] minecraft:speed 60 1 true

# Water poisons
execute if score #tick ext_tick matches 2000 run execute as @a run execute if block ~ ~-1 ~ minecraft:water run effect give @s minecraft:poison 6 0 true
execute if score #tick ext_tick matches 4000 run execute as @a run execute if block ~ ~-1 ~ minecraft:water run effect give @s minecraft:poison 6 0 true
execute if score #tick ext_tick matches 6000 run execute as @a run execute if block ~ ~-1 ~ minecraft:water run effect give @s minecraft:poison 6 0 true
execute if score #tick ext_tick matches 8000 run execute as @a run execute if block ~ ~-1 ~ minecraft:water run effect give @s minecraft:poison 6 0 true
execute if score #tick ext_tick matches 10000 run execute as @a run execute if block ~ ~-1 ~ minecraft:water run effect give @s minecraft:poison 6 0 true
execute if score #tick ext_tick matches 12000 run execute as @a run execute if block ~ ~-1 ~ minecraft:water run effect give @s minecraft:poison 6 0 true
execute if score #tick ext_tick matches 14000 run execute as @a run execute if block ~ ~-1 ~ minecraft:water run effect give @s minecraft:poison 6 0 true
execute if score #tick ext_tick matches 16000 run execute as @a run execute if block ~ ~-1 ~ minecraft:water run effect give @s minecraft:poison 6 0 true
execute if score #tick ext_tick matches 18000 run execute as @a run execute if block ~ ~-1 ~ minecraft:water run effect give @s minecraft:poison 6 0 true
execute if score #tick ext_tick matches 20000 run execute as @a run execute if block ~ ~-1 ~ minecraft:water run effect give @s minecraft:poison 6 0 true

# Hunger drain constant
execute if score #tick ext_tick matches 0 run effect give @a minecraft:hunger 30 0 true
execute if score #tick ext_tick matches 6000 run effect give @a minecraft:hunger 30 0 true
execute if score #tick ext_tick matches 12000 run effect give @a minecraft:hunger 30 0 true
execute if score #tick ext_tick matches 18000 run effect give @a minecraft:hunger 30 0 true

# Wither starts spawning phase 6+
execute if score #tick ext_tick matches 5000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:wither ~ ~5 ~
execute if score #tick ext_tick matches 16000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:wither ~ ~5 ~

# Meteors
execute if score #tick ext_tick matches 3000 run execute as @a at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 9000 run execute as @a at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 17000 run execute as @a at @s run function extinction:util/meteor_small

# Phantom swarm
execute if score #tick ext_tick matches 2000 run execute as @a at @s run summon minecraft:phantom ~ ~20 ~
execute if score #tick ext_tick matches 5000 run execute as @a at @s run summon minecraft:phantom ~3 ~15 ~3
execute if score #tick ext_tick matches 9000 run execute as @a at @s run summon minecraft:phantom ~-3 ~20 ~
execute if score #tick ext_tick matches 13000 run execute as @a at @s run summon minecraft:phantom ~ ~18 ~-3
execute if score #tick ext_tick matches 18000 run execute as @a at @s run summon minecraft:phantom ~ ~22 ~
execute if score #tick ext_tick matches 22000 run execute as @a at @s run summon minecraft:phantom ~3 ~20 ~-3

# Sounds — corruption gurgling, elder curses, wither groans
execute if score #tick ext_tick matches 1000 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 1 0.4
execute if score #tick ext_tick matches 3500 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 0.8 0.5
execute if score #tick ext_tick matches 6000 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 1 0.3
execute if score #tick ext_tick matches 9000 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 1 0.5
execute if score #tick ext_tick matches 12000 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 1 0.4
execute if score #tick ext_tick matches 15000 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 0.8 0.5
execute if score #tick ext_tick matches 18500 run playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 0.7 0.6
execute if score #tick ext_tick matches 21000 run playsound minecraft:entity.wither.shoot ambient @a ~ ~ ~ 0.6 0.4

# Night forever
execute if score #tick ext_tick matches 0 run time set 18000
execute if score #tick ext_tick matches 12000 run time set 18000
