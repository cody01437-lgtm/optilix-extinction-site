# === PHASE 8 START — Sirens & Countdown ===
bossbar set extinction:timer color red
bossbar set extinction:phase color red
bossbar set extinction:timer value 24000
playsound minecraft:entity.wither.spawn ambient @a ~ ~ ~ 2 0.3
playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 2 0.5
effect give @a minecraft:nausea 5 1 true
