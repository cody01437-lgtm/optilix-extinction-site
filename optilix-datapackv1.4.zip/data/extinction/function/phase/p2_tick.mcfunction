# === PHASE 2 TICK ===
execute if score #tick ext_tick matches 0 run effect give @a minecraft:darkness 30 1 true
execute if score #tick ext_tick matches 6000 run effect give @a minecraft:darkness 30 1 true
execute if score #tick ext_tick matches 12000 run effect give @a minecraft:darkness 30 1 true
execute if score #tick ext_tick matches 18000 run effect give @a minecraft:darkness 30 1 true

# CROPS — scan a wide Y range around the player to actually hit farmland level
# Players stand ON farmland so crops are at ~ ~ ~ and ~-1 is farmland
# Use Y range ~-1 to ~2 to catch all crop heights
execute if score #tick ext_tick matches 3000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:wheat
execute if score #tick ext_tick matches 3000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:carrots
execute if score #tick ext_tick matches 3000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:potatoes
execute if score #tick ext_tick matches 3000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:beetroots
execute if score #tick ext_tick matches 3000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:melon_stem
execute if score #tick ext_tick matches 3000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:pumpkin_stem
execute if score #tick ext_tick matches 3000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:sugar_cane

execute if score #tick ext_tick matches 11000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:wheat
execute if score #tick ext_tick matches 11000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:carrots
execute if score #tick ext_tick matches 11000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:potatoes
execute if score #tick ext_tick matches 11000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:beetroots
execute if score #tick ext_tick matches 11000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:sugar_cane

execute if score #tick ext_tick matches 19000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:wheat
execute if score #tick ext_tick matches 19000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:carrots
execute if score #tick ext_tick matches 19000 run execute as @a at @s run fill ~-8 ~-1 ~-8 ~8 ~2 ~8 minecraft:air replace minecraft:potatoes

# Compass spin (nausea)
execute if score #tick ext_tick matches 5000 run effect give @a minecraft:nausea 5 0 true
execute if score #tick ext_tick matches 15000 run effect give @a minecraft:nausea 5 0 true

# Sounds
execute if score #tick ext_tick matches 2000 run playsound minecraft:ambient.cave ambient @a ~ ~ ~ 1 0.8
execute if score #tick ext_tick matches 7000 run playsound minecraft:block.beacon.deactivate ambient @a ~ ~ ~ 0.5 0.6
execute if score #tick ext_tick matches 11000 run playsound minecraft:ambient.cave ambient @a ~ ~ ~ 1 0.7
execute if score #tick ext_tick matches 17000 run playsound minecraft:ambient.cave ambient @a ~ ~ ~ 1 0.6
execute if score #tick ext_tick matches 21000 run playsound minecraft:block.beacon.deactivate ambient @a ~ ~ ~ 0.5 0.5

# Kill animals
execute if score #tick ext_tick matches 4000 run kill @e[type=minecraft:cow,distance=..40]
execute if score #tick ext_tick matches 8000 run kill @e[type=minecraft:sheep,distance=..40]
execute if score #tick ext_tick matches 12000 run kill @e[type=minecraft:pig,distance=..40]
execute if score #tick ext_tick matches 16000 run kill @e[type=minecraft:chicken,distance=..40]
execute if score #tick ext_tick matches 20000 run kill @e[type=minecraft:horse,distance=..40]
