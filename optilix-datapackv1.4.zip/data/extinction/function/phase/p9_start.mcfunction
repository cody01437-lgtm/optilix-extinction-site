# === PHASE 9 START — The End of All ===
bossbar set extinction:timer color red
bossbar set extinction:phase color red
bossbar set extinction:timer name {"text":"☠ ☠ ☠  PHASE IX  ☠ ☠ ☠","color":"dark_red","bold":true}
playsound minecraft:entity.wither.death ambient @a ~ ~ ~ 2 0.3
playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 2 0.4
playsound minecraft:entity.lightning_bolt.thunder ambient @a ~ ~ ~ 2 0.5

execute as @a at @s run summon minecraft:wither ~ ~5 ~
execute as @a at @s run summon minecraft:wither ~10 ~5 ~10
execute as @a at @s run summon minecraft:wither ~-10 ~5 ~-10
execute as @a at @s run summon minecraft:wither ~10 ~5 ~-10
execute as @a at @s run function extinction:util/meteor_large
execute as @a at @s run function extinction:util/meteor_large
summon minecraft:lightning_bolt ~ ~ ~

effect give @a minecraft:blindness 10 1 true
effect give @a minecraft:nausea 10 2 true
effect give @a minecraft:weakness 99999 3 true
effect give @a minecraft:hunger 99999 3 true
effect give @a minecraft:darkness 99999 4 true
time set 18000
