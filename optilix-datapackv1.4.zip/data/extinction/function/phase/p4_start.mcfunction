# === PHASE 4 START — Earth Fights Back ===
bossbar set extinction:timer color red
bossbar set extinction:phase color red
playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 0.5 0.5
playsound minecraft:block.anvil.land ambient @a ~ ~ ~ 1 0.4
effect give @a minecraft:nausea 5 1 true
