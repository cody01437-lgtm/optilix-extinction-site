# === PHASE 1 TICK ===
execute if score #tick ext_tick matches 0 run effect give @a minecraft:darkness 30 0 true
execute if score #tick ext_tick matches 6000 run effect give @a minecraft:darkness 30 0 true
execute if score #tick ext_tick matches 12000 run effect give @a minecraft:darkness 30 0 true
execute if score #tick ext_tick matches 18000 run effect give @a minecraft:darkness 30 0 true

# Cave sounds — irregular timing to feel wrong
execute if score #tick ext_tick matches 800 run playsound minecraft:ambient.cave ambient @a ~ ~ ~ 1 0.6
execute if score #tick ext_tick matches 3300 run playsound minecraft:ambient.cave ambient @a ~ ~ ~ 1 0.5
execute if score #tick ext_tick matches 5900 run playsound minecraft:ambient.cave ambient @a ~ ~ ~ 1 0.7
execute if score #tick ext_tick matches 9100 run playsound minecraft:ambient.cave ambient @a ~ ~ ~ 1 0.4
execute if score #tick ext_tick matches 14700 run playsound minecraft:ambient.cave ambient @a ~ ~ ~ 1 0.8
execute if score #tick ext_tick matches 19200 run playsound minecraft:ambient.cave ambient @a ~ ~ ~ 1 0.5

# Kill passive mobs silently
execute if score #tick ext_tick matches 2000 run kill @e[type=minecraft:cow,distance=..30]
execute if score #tick ext_tick matches 4000 run kill @e[type=minecraft:sheep,distance=..30]
execute if score #tick ext_tick matches 6000 run kill @e[type=minecraft:pig,distance=..30]
execute if score #tick ext_tick matches 8000 run kill @e[type=minecraft:chicken,distance=..30]
execute if score #tick ext_tick matches 10000 run kill @e[type=minecraft:rabbit,distance=..30]
execute if score #tick ext_tick matches 14000 run kill @e[type=minecraft:cow,distance=..30]
execute if score #tick ext_tick matches 18000 run kill @e[type=minecraft:sheep,distance=..30]
