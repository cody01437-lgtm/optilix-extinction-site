# === PHASE 5 START — First Impact ===
bossbar set extinction:timer color red
bossbar set extinction:phase color red
playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 2 0.5
playsound minecraft:entity.lightning_bolt.thunder ambient @a ~ ~ ~ 2 0.6
playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 1 0.4
effect give @a minecraft:nausea 8 1 true
summon minecraft:lightning_bolt ~ ~ ~
