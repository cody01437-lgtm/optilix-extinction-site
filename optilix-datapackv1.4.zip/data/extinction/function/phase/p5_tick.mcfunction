# === PHASE 5 TICK — First Impact ===
execute if score #tick ext_tick matches 0 run effect give @a minecraft:darkness 30 3 true
execute if score #tick ext_tick matches 6000 run effect give @a minecraft:darkness 30 3 true
execute if score #tick ext_tick matches 12000 run effect give @a minecraft:darkness 30 3 true
execute if score #tick ext_tick matches 18000 run effect give @a minecraft:darkness 30 3 true

# Meteors — much more frequent, hitting EVERY player not just one
execute if score #tick ext_tick matches 1500 run execute as @a at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 4000 run execute as @a[limit=2,sort=random] at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 7000 run execute as @a at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 10000 run execute as @a[limit=2,sort=random] at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 13000 run execute as @a at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 16000 run execute as @a[limit=2,sort=random] at @s run function extinction:util/meteor_small
execute if score #tick ext_tick matches 20000 run execute as @a at @s run function extinction:util/meteor_small

# Fires
execute if score #tick ext_tick matches 3000 run execute as @a[limit=1,sort=random] at @s run fill ~5 ~1 ~5 ~10 ~1 ~10 minecraft:fire
execute if score #tick ext_tick matches 8000 run execute as @a[limit=1,sort=random] at @s run fill ~-5 ~1 ~-5 ~-10 ~1 ~-10 minecraft:fire
execute if score #tick ext_tick matches 14000 run execute as @a[limit=1,sort=random] at @s run fill ~8 ~1 ~-8 ~12 ~1 ~-12 minecraft:fire

# Lightning
execute if score #tick ext_tick matches 2000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:lightning_bolt ~5 ~ ~5
execute if score #tick ext_tick matches 6500 run execute as @a[limit=1,sort=random] at @s run summon minecraft:lightning_bolt ~-5 ~ ~3
execute if score #tick ext_tick matches 11000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:lightning_bolt ~3 ~ ~-5
execute if score #tick ext_tick matches 17000 run execute as @a[limit=1,sort=random] at @s run summon minecraft:lightning_bolt ~-3 ~ ~-3

# Impact nausea
execute if score #tick ext_tick matches 1500 run effect give @a minecraft:nausea 4 1 true
execute if score #tick ext_tick matches 7000 run effect give @a minecraft:nausea 4 1 true
execute if score #tick ext_tick matches 13000 run effect give @a minecraft:nausea 4 1 true
execute if score #tick ext_tick matches 20000 run effect give @a minecraft:nausea 3 1 true

# Sounds layered
execute if score #tick ext_tick matches 1500 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 2 0.5
execute if score #tick ext_tick matches 1700 run playsound minecraft:entity.lightning_bolt.thunder ambient @a ~ ~ ~ 2 0.6
execute if score #tick ext_tick matches 4000 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 1.5 0.6
execute if score #tick ext_tick matches 7000 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 2 0.5
execute if score #tick ext_tick matches 9000 run playsound minecraft:entity.wither.ambient ambient @a ~ ~ ~ 1 0.3
execute if score #tick ext_tick matches 13000 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 2 0.5
execute if score #tick ext_tick matches 13200 run playsound minecraft:entity.lightning_bolt.thunder ambient @a ~ ~ ~ 2 0.4
execute if score #tick ext_tick matches 18000 run playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 1.5 0.6
execute if score #tick ext_tick matches 20000 run playsound minecraft:entity.lightning_bolt.thunder ambient @a ~ ~ ~ 2 0.5

# Time stays night
execute if score #tick ext_tick matches 0 run time set 18000
execute if score #tick ext_tick matches 12000 run time set 18000

# Phantoms escalate
execute if score #tick ext_tick matches 3000 run execute as @a at @s run summon minecraft:phantom ~ ~20 ~
execute if score #tick ext_tick matches 8000 run execute as @a at @s run summon minecraft:phantom ~3 ~18 ~-3
execute if score #tick ext_tick matches 14000 run execute as @a at @s run summon minecraft:phantom ~-3 ~22 ~3
execute if score #tick ext_tick matches 19000 run execute as @a at @s run summon minecraft:phantom ~ ~20 ~
