# === PHASE 1 START — "Something's Off" ===
bossbar set extinction:timer visible true
bossbar set extinction:timer color white
bossbar set extinction:phase visible true
bossbar set extinction:phase color white
playsound minecraft:ambient.cave ambient @a ~ ~ ~ 1 0.8
