# === PHASE 10 — EXTINCTION ===
bossbar set extinction:timer color red
bossbar set extinction:phase color red
bossbar set extinction:timer value 0
effect give @a minecraft:blindness 5 255 true
effect give @a minecraft:nausea 5 2 true
playsound minecraft:entity.wither.death ambient @a ~ ~ ~ 2 0.2
playsound minecraft:entity.generic.explode ambient @a ~ ~ ~ 2 0.3
kill @e[type=!minecraft:player]
schedule function extinction:util/final_kick 100t
