# === PHASE 7 START — Reality Breaking ===
bossbar set extinction:timer color purple
bossbar set extinction:phase color purple
playsound minecraft:entity.elder_guardian.curse ambient @a ~ ~ ~ 1 0.5
playsound minecraft:entity.wither.shoot ambient @a ~ ~ ~ 1 0.3
effect give @a minecraft:blindness 5 0 true
effect give @a minecraft:nausea 10 2 true
